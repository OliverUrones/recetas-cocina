<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MenuPlato Entity.
 *
 * @property int $menu_id
 * @property \App\Model\Entity\Menu $menu
 * @property int $receta_id
 * @property \App\Model\Entity\Receta $receta
 */
class MenuPlato extends Entity
{

}
